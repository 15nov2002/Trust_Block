import 'package:flutter/material.dart';

const webScreenSize = 600;
