import 'package:flutter/material.dart';

const mobileBackGroundColor = Color.fromRGBO(255, 255, 255, 1);
const loginButtonColor = Color.fromRGBO(156, 28, 28, 1);
const textFieldColorBG = Color.fromRGBO(217, 217, 217, 1);
const primaryColor = Color.fromRGBO(240, 255, 229, 1);
